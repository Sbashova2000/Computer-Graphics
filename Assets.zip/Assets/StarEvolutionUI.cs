using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

// ============================================================
//  UI ЗА ЕВОЛЮЦИЯТА НА ЗВЕЗДАТА
//  Показва текущия стадий, описание и прогрес
// ============================================================

public class StarEvolutionUI : MonoBehaviour
{
    [Header("TextMeshPro елементи")]
    public TextMeshProUGUI stageTitle;       // "Черна дупка"
    public TextMeshProUGUI stageDescription;
    public TextMeshProUGUI stageCounter;     // "Стадий 6 / 6"
    public TextMeshProUGUI physicsFactText;  // Интересен факт

    [Header("Прогрес бар")]
    public Slider progressBar;
    public Image  progressBarFill; // цветът му се мени

    [Header("Цветове за всеки стадий")]
    public Color nebulaColor       = new Color(0.4f, 0.2f, 0.8f);  // лилаво
    public Color protostarColor     = new Color(1f,   0.4f, 0f);    // оранжево
    public Color mainSequenceColor  = new Color(1f,   0.9f, 0.2f);  // жълто
    public Color redGiantColor      = new Color(0.9f, 0.1f, 0.05f); // червено
    public Color supernovaColor     = new Color(1f,   1f,   1f);    // бяло
    public Color blackHoleColor     = new Color(0.4f, 0.2f, 0.8f);  // лилаво

    // Физични факти за всеки стадий
    private static readonly string[] PhysicsFacts =
    {
        "Гравитацията свива облака. Когато T > 10⁷ K, започва ядрен синтез.",
        "Протозвездата свети от гравитационна енергия, НЕ от ядрен синтез.",
        "Слънцето е в главната последователност от ~5 млрд. години.",
        "Червеният свръхгигант може да е 1000 пъти по-голям от Слънцето!",
        "Свръхновата за секунди излъчва повече енергия от цялата галактика.",
        "При черна дупка: втора космическа скорост > скоростта на светлината (c).\nSchwarzschild радиус: r = 2GM/c²"
    };

    private Color[] stageColors;

    void Awake()
    {
        stageColors = new Color[]
        {
            nebulaColor, protostarColor, mainSequenceColor,
            redGiantColor, supernovaColor, blackHoleColor
        };
    }

    // Извиква се от StarEvolution при смяна на стадий
    public void UpdateStage(int stage)
    {
        if (stage < 0 || stage >= StarEvolution.StageNames.Length) return;

        // Текст
        if (stageTitle)
            stageTitle.text = StarEvolution.StageNames[stage];

        if (stageDescription)
            stageDescription.text = StarEvolution.StageDescriptions[stage];

        if (stageCounter)
            stageCounter.text = $"Стадий {stage + 1} / {StarEvolution.StageNames.Length}";

        if (physicsFactText)
            physicsFactText.text = "💡 " + PhysicsFacts[stage];

        // Прогрес бар
        if (progressBar)
        {
            progressBar.value = (float)stage / (StarEvolution.StageNames.Length - 1);
        }

        // Цвят
        Color c = stageColors[stage];
        if (progressBarFill) progressBarFill.color = c;
        if (stageTitle)      stageTitle.color       = c;

        // Анимира появата на текста
        StartCoroutine(FadeInText());
    }

    IEnumerator FadeInText()
    {
        if (stageDescription == null) yield break;

        // Избледнява и после се появява отново
        for (float a = 1f; a >= 0f; a -= Time.deltaTime * 4f)
        {
            stageDescription.alpha = a;
            yield return null;
        }
        for (float a = 0f; a <= 1f; a += Time.deltaTime * 3f)
        {
            stageDescription.alpha = a;
            yield return null;
        }
        stageDescription.alpha = 1f;
    }
}
