using UnityEngine;
using System.Collections;

// ============================================================
//  ЕВОЛЮЦИЯ НА ЗВЕЗДАТА → ЧЕРНА ДУПКА
//  Физика 10 клас | Урок: Еволюция на звездите (Булвест)
// ============================================================
//
//  СТАДИИ НА АНИМАЦИЯТА:
//  0. Мъглявина       — облак от газ и прах, свива се бавно
//  1. Протозвезда     — нагрява се, светва в оранжево
//  2. Главна посл.    — жълта стабилна звезда (като Слънцето)
//  3. Червен свръхгигант — разширява се, почервенява
//  4. Свръхнова       — огромна експлозия, ударна вълна
//  5. Черна дупка     — всичко се засмуква в черна точка
// ============================================================

public class StarEvolution : MonoBehaviour
{
    [Header("Компоненти на звездата")]
    [Tooltip("Renderer на сферата (звездата)")]
    public Renderer starRenderer;

    [Tooltip("Point Light на звездата")]
    public Light starLight;

    [Tooltip("Particle System за мъглявината (Nebula)")]
    public ParticleSystem nebulaParticles;

    [Tooltip("Particle System за експлозията (Supernova)")]
    public ParticleSystem supernovaParticles;

    [Tooltip("Particle System за акреционния диск на черната дупка")]
    public ParticleSystem accretionDiskParticles;

    [Header("UI")]
    [Tooltip("Скриптът за UI текст")]
    public StarEvolutionUI uiScript;

    // ---- Настройки на стадиите ----
    [Header("Времетраене на всеки стадий (секунди)")]
    public float nebulaDuration        = 4f;
    public float protostarDuration     = 3f;
    public float mainSequenceDuration  = 4f;
    public float redGiantDuration      = 3f;
    public float supernovaDuration     = 3f;
    public float blackHoleDuration     = 5f;

    // ---- Вътрешни ----
    private Material starMat;
    private int currentStage = 0;

    // Имена на стадиите (показват се на UI)
    public static readonly string[] StageNames =
    {
        "Мъглявина",
        "Протозвезда",
        "Главна последователност",
        "Червен свръхгигант",
        "Свръхнова",
        "Черна дупка"
    };

    public static readonly string[] StageDescriptions =
    {
        "Облак от газ и прах се свива под гравитацията си.",
        "Центърът се нагрява до ~10⁷ K. Започва термоядрен синтез.",
        "Водородът гори в хелий. Звездата е стабилна милиарди години.",
        "Водородът свършва. Звездата се разширява и охлажда.",
        "Ядрото колабира. Огромна експлозия разпръсква материята.",
        "Ядрото > 3M☉ → никаква сила не спира гравитацията.\nСветлината не може да избяга!"
    };

    public int CurrentStage => currentStage;

    void Start()
    {
        // Вземи материала (instance, за да не се промени оригиналът)
        starMat = starRenderer.material;

        // Спри всички particle systems
        StopAllParticles();

        // Стартирай анимацията
        StartCoroutine(RunEvolution());
    }

    // ============================================================
    // изпълняват се стадиите по ред
    // ============================================================
    IEnumerator RunEvolution()
    {
        yield return StartCoroutine(Stage0_Nebula());
        yield return StartCoroutine(Stage1_Protostar());
        yield return StartCoroutine(Stage2_MainSequence());
        yield return StartCoroutine(Stage3_RedSuperGiant());
        yield return StartCoroutine(Stage4_Supernova());
        yield return StartCoroutine(Stage5_BlackHole());
    }

    // ============================================================
    //  СТАДИЙ 0: МЪГЛЯВИНА
    //  Облак от газ, бавно се свива
    // ============================================================
    IEnumerator Stage0_Nebula()
    {
        currentStage = 0;
        NotifyUI();

        // Скрий звездата, пусни мъглявина
        starRenderer.enabled = false;
        if (starLight) starLight.enabled = false;
        if (nebulaParticles) nebulaParticles.Play();

        // Бавно свиване: мъглявината се уголемява → звездата се появява
        float t = 0f;
        while (t < nebulaDuration)
        {
            t += Time.deltaTime;
            // Мащабиране на particle system (симулира свиване на облака)
            if (nebulaParticles)
            {
                var main = nebulaParticles.main;
                main.startSizeMultiplier = Mathf.Lerp(3f, 0.5f, t / nebulaDuration);
            }
            yield return null;
        }

        if (nebulaParticles) nebulaParticles.Stop();
    }

    // ============================================================
    //  СТАДИЙ 1: ПРОТОЗВЕЗДА
    //  Нагрява се, оранжева, малка
    // ============================================================
    IEnumerator Stage1_Protostar()
    {
        currentStage = 1;
        NotifyUI();

        starRenderer.enabled = true;
        if (starLight) starLight.enabled = true;

        // Начален размер — много малък
        transform.localScale = Vector3.one * 0.1f;

        float t = 0f;
        while (t < protostarDuration)
        {
            t += Time.deltaTime;
            float progress = t / protostarDuration;

            // Нараства до размер 1
            float size = Mathf.Lerp(0.1f, 1f, progress);
            transform.localScale = Vector3.one * size;

            // Цвят: тъмно оранжево → ярко оранжево
            Color protoColor = Color.Lerp(new Color(0.6f, 0.2f, 0f), new Color(1f, 0.5f, 0f), progress);
            starMat.SetColor("_EmissionColor", protoColor * 2f);
            starMat.color = protoColor;

            // Светлина
            if (starLight)
            {
                starLight.color     = protoColor;
                starLight.intensity = Mathf.Lerp(0.5f, 2f, progress);
                starLight.range     = Mathf.Lerp(3f, 8f, progress);
            }

            yield return null;
        }
    }

    // ============================================================
    //  СТАДИЙ 2: ГЛАВНА ПОСЛЕДОВАТЕЛНОСТ
    //  Жълта, стабилна (като Слънцето), пулсира леко
    // ============================================================
    IEnumerator Stage2_MainSequence()
    {
        currentStage = 2;
        NotifyUI();

        Color sunColor = new Color(1f, 0.95f, 0.3f); // жълто

        float t = 0f;
        while (t < mainSequenceDuration)
        {
            t += Time.deltaTime;

            // Лека пулсация — показва, че горенето е активно
            float pulse = 1f + 0.05f * Mathf.Sin(t * 3f);
            transform.localScale = Vector3.one * pulse;

            starMat.SetColor("_EmissionColor", sunColor * 3f);
            starMat.color = sunColor;

            if (starLight)
            {
                starLight.color     = sunColor;
                starLight.intensity = 3f + 0.3f * Mathf.Sin(t * 3f);
                starLight.range     = 15f;
            }

            yield return null;
        }
    }

    // ============================================================
    //  СТАДИЙ 3: ЧЕРВЕН СВРЪХГИГАНТ
    //  Разширява се, почервенява
    // ============================================================
    IEnumerator Stage3_RedSuperGiant()
    {
        currentStage = 3;
        NotifyUI();

        Color yellowColor = new Color(1f, 0.95f, 0.3f);
        Color redColor    = new Color(1f, 0.15f, 0.05f);

        float t = 0f;
        while (t < redGiantDuration)
        {
            t += Time.deltaTime;
            float progress = t / redGiantDuration;

            // Разширяване: 1 → 4 (4 пъти по-голяма!)
            float size = Mathf.Lerp(1f, 4f, Mathf.SmoothStep(0, 1, progress));
            transform.localScale = Vector3.one * size;

            // Цвят: жълто → тъмно червено
            Color c = Color.Lerp(yellowColor, redColor, progress);
            starMat.SetColor("_EmissionColor", c * 1.5f);
            starMat.color = c;

            if (starLight)
            {
                starLight.color     = c;
                starLight.intensity = Mathf.Lerp(3f, 1.5f, progress);
                starLight.range     = Mathf.Lerp(15f, 25f, progress);
            }

            yield return null;
        }
    }

    // ============================================================
    //  СТАДИЙ 4: СВРЪХНОВА — ВЗРИВ!
    //  Светва ярко, след това се свива рязко
    // ============================================================
    IEnumerator Stage4_Supernova()
    {
        currentStage = 4;
        NotifyUI();

        // Фаза 1: Мигновена светкавица (0.5s)
        if (supernovaParticles) supernovaParticles.Play();

        float flashTime = 0.5f;
        float t = 0f;
        while (t < flashTime)
        {
            t += Time.deltaTime;
            float brightness = Mathf.Lerp(1.5f, 20f, t / flashTime);
            starMat.SetColor("_EmissionColor", Color.white * brightness);
            if (starLight)
            {
                starLight.color     = Color.white;
                starLight.intensity = brightness * 3f;
                starLight.range     = 50f;
            }
            yield return null;
        }

        // Фаза 2: Ударната вълна се разширява, ядрото се свива (2.5s)
        t = 0f;
        float remainingTime = supernovaDuration - flashTime;
        while (t < remainingTime)
        {
            t += Time.deltaTime;
            float progress = t / remainingTime;

            // Звездата се свива бързо
            float size = Mathf.Lerp(4f, 0.05f, Mathf.Pow(progress, 0.5f));
            transform.localScale = Vector3.one * size;

            // Избледнява
            Color c = Color.Lerp(Color.white, Color.black, progress);
            starMat.SetColor("_EmissionColor", c * Mathf.Lerp(20f, 0f, progress));
            starMat.color = Color.Lerp(Color.white, Color.black, progress);

            if (starLight)
                starLight.intensity = Mathf.Lerp(60f, 0f, progress);

            yield return null;
        }
    }

    // ============================================================
    //  СТАДИЙ 5: ЧЕРНА ДУПКА
    //  Черна сфера, акреционен диск, засмуква светлина
    // ============================================================
    IEnumerator Stage5_BlackHole()
    {
        currentStage = 5;
        NotifyUI();

        // Черна дупка е черна — никаква светлина не излиза
        starMat.color = Color.black;
        starMat.SetColor("_EmissionColor", Color.black);
        if (starLight) starLight.enabled = false;

        // Пуска акреционния диск (светещ газ около черната дупка)
        if (accretionDiskParticles) accretionDiskParticles.Play();

        // Бавно нарастване на черната дупка
        float t = 0f;
        while (t < blackHoleDuration)
        {
            t += Time.deltaTime;
            float progress = t / blackHoleDuration;

            // Черната дупка нараства от 0.05 до 0.5
            float size = Mathf.Lerp(0.05f, 0.5f, Mathf.SmoothStep(0, 1, progress));
            transform.localScale = Vector3.one * size;

            // Завъртане — черните дупки се въртят!
            transform.Rotate(Vector3.up, 30f * Time.deltaTime);

            yield return null;
        }

        // Рестартира анимацията след завършване
        yield return new WaitForSeconds(2f);
        transform.localScale = Vector3.one * 0.1f;
        StopAllParticles();
        StartCoroutine(RunEvolution());
    }

    // ---- Помощни функции ----

    void StopAllParticles()
    {
        if (nebulaParticles)       nebulaParticles.Stop();
        if (supernovaParticles)    supernovaParticles.Stop();
        if (accretionDiskParticles) accretionDiskParticles.Stop();
    }

    void NotifyUI()
    {
        if (uiScript != null)
            uiScript.UpdateStage(currentStage);
    }
}
