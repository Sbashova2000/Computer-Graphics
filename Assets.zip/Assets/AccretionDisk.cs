using UnityEngine;

// ============================================================
//  АКРЕЦИОНЕН ДИСК НА ЧЕРНА ДУПКА
//  Физика 10 клас | Урок: Еволюция на звездите
// ============================================================
//
//  Акреционният диск е материя (газ и прах), която се
//  върти около черната дупка преди да бъде погълната.
//  Загрява се до милиони градуса и свети ярко.
//
// ============================================================

public class AccretionDisk : MonoBehaviour
{
    [Header("Компоненти")]
    public StarEvolution starScript;
    public ParticleSystem diskParticles;

    [Header("Параметри на диска")]
    [Tooltip("Скорост на въртене на диска (градуси/сек)")]
    public float rotationSpeed = 45f;

    [Tooltip("Вътрешен радиус на диска")]
    public float innerRadius = 0.6f;

    [Tooltip("Външен радиус на диска")]
    public float outerRadius = 2f;

    private bool isActive = false;

    void Update()
    {
        // Показва диска само в стадия на черната дупка (стадий 5)
        bool shouldBeActive = (starScript != null && starScript.CurrentStage == 5);

        if (shouldBeActive && !isActive)
        {
            isActive = true;
            if (diskParticles && !diskParticles.isPlaying)
                diskParticles.Play();
        }
        else if (!shouldBeActive && isActive)
        {
            isActive = false;
            if (diskParticles && diskParticles.isPlaying)
                diskParticles.Stop();
        }

        if (isActive)
        {
            // Въртене на диска около оста Y
            transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);

            // Леко накланя диска (черните дупки са наклонени)
            transform.localEulerAngles = new Vector3(
                15f,
                transform.localEulerAngles.y,
                0f
            );

            // Обновява частиците да се движат в кръг
            UpdateParticleMovement();
        }
    }

    void UpdateParticleMovement()
    {
        if (diskParticles == null) return;

        // Достъп до частиците
        ParticleSystem.Particle[] particles = new ParticleSystem.Particle[diskParticles.particleCount];
        int count = diskParticles.GetParticles(particles);

        for (int i = 0; i < count; i++)
        {
            Vector3 pos  = particles[i].position;
            float   dist = new Vector2(pos.x, pos.z).magnitude;

            if (dist < 0.01f) continue;

            // По-близо до черната дупка → по-бързо въртене
            // v ∝ 1/√r (Keplerian orbit)
            float speed = 2f / Mathf.Sqrt(dist + 0.1f);

            // Тангенциална скорост (перпендикулярна на радиус-вектора)
            Vector3 tangent = new Vector3(-pos.z, 0f, pos.x).normalized;
            particles[i].velocity = tangent * speed;

            // Ако частицата е влязла вътре в хоризонта на събитията — се унищожава
            if (dist < innerRadius * 0.3f)
                particles[i].remainingLifetime = 0f;
        }

        diskParticles.SetParticles(particles, count);
    }

    // Рисуване на хоризонта на събитията
    void OnDrawGizmosSelected()
    {
        // Schwarzschild радиус (хоризонт на събитията)
        Gizmos.color = Color.red;
        DrawCircle(transform.position, innerRadius, 32);

        // Вътрешна стабилна кръгова орбита (ISCO)
        Gizmos.color = Color.yellow;
        DrawCircle(transform.position, innerRadius * 3f, 32);

        // Фотонна сфера
        Gizmos.color = Color.cyan;
        DrawCircle(transform.position, innerRadius * 1.5f, 32);
    }

    void DrawCircle(Vector3 center, float r, int segments)
    {
        float angleStep = 360f / segments;
        for (int i = 0; i < segments; i++)
        {
            float a1 = i * angleStep * Mathf.Deg2Rad;
            float a2 = (i + 1) * angleStep * Mathf.Deg2Rad;
            Vector3 p1 = center + new Vector3(Mathf.Cos(a1) * r, 0f, Mathf.Sin(a1) * r);
            Vector3 p2 = center + new Vector3(Mathf.Cos(a2) * r, 0f, Mathf.Sin(a2) * r);
            Gizmos.DrawLine(p1, p2);
        }
    }
}
