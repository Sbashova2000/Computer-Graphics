using UnityEngine;

// ============================================================
//  ФОН НА ВСЕЛЕНАТА — процедурни звезди + паралакс
//  Физика 10 клас | Урок: Еволюция на звездите
// ============================================================


public class SpaceBackground : MonoBehaviour
{
    [Header("Настройки на звездния фон")]
    [Tooltip("Брой фонови звезди")]
    public int starCount = 300;

    [Tooltip("Радиус на сферата от звезди около камерата")]
    public float radius = 50f;

    [Tooltip("Мин. размер на звезда")]
    public float minStarSize = 0.05f;

    [Tooltip("Макс. размер на звезда")]
    public float maxStarSize = 0.25f;

    [Tooltip("Скорост на мигане")]
    public float twinkleSpeed = 2f;

    [Header("Черна дупка ефект")]
    [Tooltip("Скриптът на звездата")]
    public StarEvolution starScript;

    // Пазим референции за мигане
    private GameObject[] stars;
    private float[]      twinkleOffsets;
    private Renderer[]   starRenderers;
    private Color[]      starColors;

    void Start()
    {
        GenerateStars();
    }

    void GenerateStars()
    {
        stars          = new GameObject[starCount];
        twinkleOffsets = new float[starCount];
        starRenderers  = new Renderer[starCount];
        starColors     = new Color[starCount];

        // Материал за звездите (самосветещ)
        Material starMat = new Material(Shader.Find("Standard"));
        starMat.EnableKeyword("_EMISSION");

        for (int i = 0; i < starCount; i++)
        {
            // Случайна позиция върху сферата
            Vector3 randomDir = Random.onUnitSphere;
            Vector3 pos       = randomDir * radius;

            // Създай малка сфера
            GameObject star = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            star.name       = $"Star_{i}";
            star.transform.SetParent(transform);
            star.transform.position   = pos;
            star.transform.localScale = Vector3.one * Random.Range(minStarSize, maxStarSize);

            // Изключвa колайдера
            Destroy(star.GetComponent<Collider>());

            // Цвят — звездите имат различни цветове в зависимост от температурата
            // Горещи → сини/бели,  Студени → оранжеви/червени

            Color starColor = GetRandomStarColor();
            Material mat    = new Material(starMat);
            mat.color       = starColor;
            mat.SetColor("_EmissionColor", starColor * Random.Range(1f, 3f));

            star.GetComponent<Renderer>().material = mat;

            stars[i]         = star;
            starRenderers[i] = star.GetComponent<Renderer>();
            starColors[i]    = starColor;
            twinkleOffsets[i] = Random.Range(0f, Mathf.PI * 2f);
        }

        Destroy(starMat); // почисти временния материал
    }

    void Update()
    {
        // Мигане на звездите
        for (int i = 0; i < starCount; i++)
        {
            if (starRenderers[i] == null) continue;

            float brightness = 0.7f + 0.3f * Mathf.Sin(Time.time * twinkleSpeed + twinkleOffsets[i]);
            starRenderers[i].material.SetColor("_EmissionColor", starColors[i] * brightness * 2f);
        }

        // Ефект на черна дупка - звездите "се теглят" към центъра
        if (starScript != null && starScript.CurrentStage == 5)
        {
            ApplyBlackHoleEffect();
        }
    }

    void ApplyBlackHoleEffect()
    {
        // Симулира изкривяване на пространството около черна дупка
        // Звездите леко се местят към центъра
        for (int i = 0; i < starCount; i++)
        {
            if (stars[i] == null) continue;

            Vector3 toCenter = (transform.position - stars[i].transform.position).normalized;
            float   dist     = Vector3.Distance(stars[i].transform.position, Vector3.zero);

            // Само близките звезди се "засмукват"
            if (dist < radius * 0.6f)
            {
                float pull = (1f - dist / (radius * 0.6f)) * 0.5f * Time.deltaTime;
                stars[i].transform.position += toCenter * pull;
            }
        }
    }

    //Цветове на звездите (по спектрален клас)
    Color GetRandomStarColor()
    {
        int type = Random.Range(0, 6);
        switch (type)
        {
            case 0: return new Color(0.6f, 0.7f, 1f);    // O — сини 
            case 1: return new Color(0.7f, 0.8f, 1f);    // B — синьо-бели
            case 2: return new Color(1f,   1f,   1f);    // A — бели
            case 3: return new Color(1f,   0.95f, 0.7f); // F — жълто-бели
            case 4: return new Color(1f,   0.9f,  0.4f); // G — жълти 
            case 5: return new Color(1f,   0.5f,  0.2f); // K — оранжеви
            default: return new Color(1f,  0.2f,  0.1f); // M — червени 
        }
    }

    void OnDestroy()
    {
        // Почиства всички звезди след унищожаването
        for (int i = 0; i < starCount; i++)
        {
            if (stars[i] != null) Destroy(stars[i]);
        }
    }
}
