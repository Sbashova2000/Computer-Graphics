using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    void Update()
    {
        transform.RotateAround(Vector3.zero, Vector3.up, 5f * Time.deltaTime);
    }
}